package com.cg.library.daoservice;

public interface LibraryDao {

}
