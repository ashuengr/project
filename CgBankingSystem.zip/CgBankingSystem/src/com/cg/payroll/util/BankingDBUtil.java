package com.cg.payroll.util;
import java.util.HashMap;
public class BankingDBUtil {
 public static HashMap<long,Account>accounts=new HashMap<long,Account>();
 private static long ACCOUNT_NUMBER=100;
 public static long getACCOUNT_NUMBER() {
	 return ++ACCOUNT_NUMBER;
 }
}
