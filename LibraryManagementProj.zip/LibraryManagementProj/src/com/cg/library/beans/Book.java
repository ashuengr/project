package com.cg.library.beans;

public class Book {
private int bookId;
private String bookTitle;
private String subject;
private String author;
private boolean isIssued;
public Book(int bookId, String bookTitle, String subject, String author, boolean isIssued) {
	super();
	this.bookId = bookId;
	this.bookTitle = bookTitle;
	this.subject = subject;
	this.author = author;
	this.isIssued = isIssued;
}
public Book() {
	super();
}
public int getBookId() {
	return bookId;
}
public void setBookId(int bookId) {
	this.bookId = bookId;
}
@Override
public String toString() {
	return "Book [bookId=" + bookId + ", bookTitle=" + bookTitle + ", subject=" + subject + ", author=" + author
			+ ", isIssued=" + isIssued + "]";
}
public String getBookTitle() {
	return bookTitle;
}
public void setBookTitle(String bookTitle) {
	this.bookTitle = bookTitle;
}
public String getSubject() {
	return subject;
}
public void setSubject(String subject) {
	this.subject = subject;
}
public String getAuthor() {
	return author;
}
public void setAuthor(String author) {
	this.author = author;
}
public boolean isIssued() {
	return isIssued;
}
public void setIssued(boolean isIssued) {
	this.isIssued = isIssued;
}
}
